﻿// Decompiled with JetBrains decompiler
// Type: KMSAuto_Net.My.MyComputer
// Assembly: KMSAuto Net, Version=1.3.9.0, Culture=neutral, PublicKeyToken=334b8937f48b3142
// MVID: 4B7D3064-FB93-447A-8F9C-DC4A190A5ACC
// Assembly location: D:\Desktop\KMSAuto Net-cleaned-cleaned.exe

using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

namespace KMSAuto_Net.My
{
  [GeneratedCode("MyTemplate", "11.0.0.0")]
  [EditorBrowsable(EditorBrowsableState.Never)]
  internal class MyComputer : Computer
  {
    [DebuggerHidden]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public MyComputer()
    {
    }
  }
}
