﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("MSFree Inc.")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("KMSAuto Net")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyFileVersion("1.3.9")]
[assembly: Guid("fcaa9736-cfc3-43fa-33da-378396c3a336")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("")]
[assembly: AssemblyTitle("KMSAuto Net")]
[assembly: AssemblyVersion("1.3.9.0")]
