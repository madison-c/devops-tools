﻿// Decompiled with JetBrains decompiler
// Type: KMSAuto_Net.My.Resources.Resources
// Assembly: KMSAuto Net, Version=1.3.9.0, Culture=neutral, PublicKeyToken=334b8937f48b3142
// MVID: 4B7D3064-FB93-447A-8F9C-DC4A190A5ACC
// Assembly location: D:\Desktop\KMSAuto Net-cleaned-cleaned.exe

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace KMSAuto_Net.My.Resources
{
  [DebuggerNonUserCode]
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [HideModuleName]
  [CompilerGenerated]
  [StandardModule]
  internal sealed class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) KMSAuto_Net.My.Resources.Resources.resourceMan, (object) null))
          KMSAuto_Net.My.Resources.Resources.resourceMan = new ResourceManager("KMSAuto_Net.Resources", typeof (KMSAuto_Net.My.Resources.Resources).Assembly);
        return KMSAuto_Net.My.Resources.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.resourceCulture;
      }
      set
      {
        KMSAuto_Net.My.Resources.Resources.resourceCulture = value;
      }
    }

    internal static byte[] access16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (access16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] bin
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (bin), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] bin_x64
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (bin_x64), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] bin_x86
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (bin_x86), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap Clear10
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Clear10), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap Clear101
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Clear101), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap Comodo2
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Comodo2), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] excel16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (excel16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] hidecontrol
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (hidecontrol), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap Info24
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Info24), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] Inj_dx64
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Inj_dx64), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] Inj_dx86
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Inj_dx86), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap Key24
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Key24), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap key48
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (key48), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] KMS_Log_Analyzer
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (KMS_Log_Analyzer), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] kmsclient
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (kmsclient), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap logo_kmsAutoNettransparent
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (logo_kmsAutoNettransparent), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap logo_kmsAutoNettransparent1
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (logo_kmsAutoNettransparent1), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static Bitmap movie
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (movie), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MS_Office_updates_del_EN
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (MS_Office_updates_del_EN), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MS_Office_updates_del_ES
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (MS_Office_updates_del_ES), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MS_Office_updates_del_FR
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (MS_Office_updates_del_FR), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MS_Office_updates_del_RU
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (MS_Office_updates_del_RU), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MS_Office_updates_del_UA
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (MS_Office_updates_del_UA), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] MSActBackup
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (MSActBackup), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] onenote16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (onenote16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] outlook16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (outlook16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] pdkutils
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (pdkutils), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] powerpoint16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (powerpoint16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] project
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (project), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] project16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (project16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] proplus
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (proplus), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] proplus16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (proplus16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] publisher16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (publisher16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static string readme_cn
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_cn), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_en
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_en), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_es
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_es), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_fr
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_fr), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_kms
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_kms), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_ru
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_ru), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_ua
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_ua), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static string readme_vi
    {
      get
      {
        return KMSAuto_Net.My.Resources.Resources.ResourceManager.GetString(nameof (readme_vi), KMSAuto_Net.My.Resources.Resources.resourceCulture);
      }
    }

    internal static Bitmap Save12
    {
      get
      {
        return (Bitmap) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (Save12), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] SppP_x64
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (SppP_x64), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] SppP_x86
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (SppP_x86), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] visio
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (visio), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] visio16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (visio16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] word16
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (word16), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }

    internal static byte[] wushowhide
    {
      get
      {
        return (byte[]) RuntimeHelpers.GetObjectValue(KMSAuto_Net.My.Resources.Resources.ResourceManager.GetObject(nameof (wushowhide), KMSAuto_Net.My.Resources.Resources.resourceCulture));
      }
    }
  }
}
